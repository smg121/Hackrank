<!DOCTYPE HTML>
<html>

<head>
    <title>
      CodeRank User
    </title>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="http://localhost/coderank/css/bootstrap.css">
    <link rel="stylesheet" href="http://localhost/coderank/css/style.css">
</head>

<body>





</body>

</html>