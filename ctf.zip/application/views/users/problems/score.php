		<div class="col-sm-9" >
			<h3>Score Board</h3>
			<hr>
			<div class="col-md-10">
			<table class="table table-hover" >
				<thead>
					<tr>
						<th>Problem</th>
						<th>Score</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td>Problem 1</td>
						<td><?php echo $prob1; ?></td>
					</tr>
					<tr>
						<td>Problem 2</td>
						<td><?php echo $prob2; ?></td>
					</tr>
					<tr>
						<td>Problem 3</td>
						<td><?php echo $prob3; ?></td>
					</tr>
					<tr>
						<td>Problem 4</td>
						<td><?php echo $prob4; ?></td>
					</tr>
					<tr>
						<td>Problem 5</td>
						<td><?php echo $prob5; ?></td>
					</tr>
				</tbody>
			</table>
		</div>

		</div>

	</div>
</div>


<!-- Donot change Javascripts -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script src="http://localhost/coderank/js/bootstrap.js" ></script>
</body>
</html>