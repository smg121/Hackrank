			<div class="col-sm-9">

				<h3>Compete</h3>
			<hr>
				
			</div>
		</div>
	</div>






	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script src="http://localhost/coderank/js/bootstrap.js" ></script>
</body>
</html>