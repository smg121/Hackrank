<!DOCTYPE html>
<html lang="en">
<head>
  <title>Code Rank</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://localhost/coderank/css/bootstrap.css">
  <link rel="stylesheet" href="http://localhost/coderank/css/style.css">
  

</head>

<body>

<!-- header -->
    
<?php
require("header.php");
require("main.php");
?>



<!-- footer-->

<footer class="footer">
    &copy Copyrights 2015
</footer>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script src="http://localhost/coderank/js/bootstrap.js" ></script>

</body>
</html>