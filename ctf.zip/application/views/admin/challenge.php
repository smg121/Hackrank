		<div class="col-md-9" >
			<h3>Contest name here</h3>
			<hr>
			<div class=""


		</div>

	
	</div>
  </div>

<!-- Donot touch javascript functionalities -->
              <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
              <script src="http://localhost/coderank/js/bootstrap.js" ></script>

</body>
</html>
